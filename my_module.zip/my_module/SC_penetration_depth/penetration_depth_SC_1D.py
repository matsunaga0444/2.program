from numpy import *
from basic import electron_band, fermi
from SC_BCS_Gap_equation import Gap_equation_SC_BCS_1D
from SC_BCS_free_energy import free_energy_SC_BCS_1D
from SC_coherence_length import coherence_length_1D

############################################################################################
###from GL
def v_k_1D(t, k1):
    return -2 * t * (sin(k1))

def G_f_1D(t, k1, gap, q, mu, gu, B, beta):
    a = ( -1 * Gap_equation_SC_BCS_1D.e_k_s_1D(t, k1, q, mu, gu, B) \
         + Gap_equation_SC_BCS_1D.E_k_q_1D(t, k1, q, mu, gu, B, gap))/ \
            (2 * Gap_equation_SC_BCS_1D.E_k_q_1D(t, k1, q, mu, gu, B, gap))
    b = (Gap_equation_SC_BCS_1D.e_k_s_1D(t, k1, q, mu, gu, B) \
         + Gap_equation_SC_BCS_1D.E_k_q_1D(t, k1, q, mu, gu, B, gap))/ \
            (2 * Gap_equation_SC_BCS_1D.E_k_q_1D(t, k1, q, mu, gu, B, gap))
    return (a*(1-fermi.Fermi(beta, Gap_equation_SC_BCS_1D.E_k_q_s_1D(t, k1, q, mu, -1, gu, B, gap)))) \
           +(b*fermi.Fermi(beta, Gap_equation_SC_BCS_1D.E_k_q_s_1D(t, k1, q, mu, 1, gu, B, gap)))

def current_1D(t, n_k, gap, qs, mu, gu, B, beta):
    k1 = -1 * pi + 2 * arange(n_k) * pi / (n_k)
    j_k = v_k_1D(t,k1) * G_f_1D(t, k1-(qs/2)*pi, gap, qs, mu, gu, B, beta)
    return 2 * sum(j_k)/n_k

def max_current(t,n_k, gap, xi, mu, gu, B, beta):
    q_max = 1/(sqrt(3)*xi)
    return current_1D(t,n_k, gap, q_max/pi, mu, gu, B, beta)

# def penetration_depth_GL(xi, dq, kBT, ini_gap, nscf, N, t, mu, gu, B, V, gap):
#     lamb = 1 / sqrt(6 * sqrt(3) * pi * 2 \
#             * coherence_length_1D.coherence_length_from_GL_theory_1D(dq, kBT, ini_gap, nscf, N, t, mu, gu, B, V) \
#             * max_current(t, N, gap, xi, mu, gu, B, 1/kBT))
#     return lamb

def penetration_depth_GL(xi, dq, kBT, ini_gap, nscf, N, t, mu, gu, B, V, gap):
    lamb = 1 / sqrt(12 * sqrt(3) * pi \
            * coherence_length_1D.coherence_length_from_GL_theory_1D(dq, kBT, ini_gap, nscf, N, t, mu, gu, B, V) \
            * max_current(t, N, gap, xi, mu, gu, B, 1/kBT))
    return lamb

############################################################################################
###from extended GL

def penetration_depth_from_extended_GL_1D(t, mu, gu, B, beta, V, N, dc, dq):
    return sqrt(1/(32*pi*free_energy_SC_BCS_1D.d2df_q_1D(t, mu, gu, B, beta, V, N, dc, dq)))

def free_energy_to_current(t, mu, gu, B, beta, V, N, dc, dq,q):
    return 4*free_energy_SC_BCS_1D.d2df_q_1D(t, mu, gu, B, beta, V, N, dc, dq) * q


############################################################################################
###linear_response_theory

def penetration_depth_linear_1D(t, mu, beta, N, gap):
    k1 = -1 * pi + 2 * arange(N) * pi / (N)
    e_k = electron_band.e_k_s_1D(t, k1, 0, mu, 0, 0, 0)
    dfE  = fermi.derivative_Fermi_function(beta, sqrt(e_k**2+gap**2))
    dfxi = fermi.derivative_Fermi_function(beta, e_k)
    #f = (k1)**2 * (dfE-dfxi)
    f = (-2*t*sin(k1))**2 * (dfE-dfxi)
    # return 1/sqrt(sum(f))
    return 1/sqrt(2*pi*sum(f)/(N))
