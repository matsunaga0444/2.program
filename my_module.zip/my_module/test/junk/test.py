from numpy import *
import matplotlib.pyplot as plt
import Gap_equation_SC_BCS.Gap_equation_SC_BCS as Gap_equation_SC_BCS
import penetration_depth.penetration_depth_SC as penetration_depth_SC
import coherence_length.coherence_length as coherence_length

##パラメータの調整
h = pi
N, V, t, mu, gu, n0, n1, n2, nscf =1000, 2, 1 , 0, 1, 2, 1, 30, 2000  # 7.525 #9.21
n_search, error, check_gap =100, 1e-10, 1e-6
kBT_a, kBT_b = 0.0001, 2
wide_q = 0.001
qs   = linspace(0,wide_q,n0)         #(np.pi/a)
Bs   = linspace(0.0,0.0,n1)          #np.linspace(0,0.08,n1)
kBTs = linspace(0.01,0.2,n2)
ini_gap = 100

ans = Gap_equation_SC_BCS.scf_1D(n0, n1, n2, kBTs, ini_gap, nscf, N, t, qs, mu, gu, Bs, V)

ans_lamb = []
ans_xi = []
ans_jdp = []
for i in range(n2):
    xi   = coherence_length.coherence_length_Niklas(ans[1,0,i,0], ans[0,0,i,0], qs[1])
    beta = 1/kBTs[i]
    jdp  = penetration_depth_SC.max_current(t, N, ans[0,0,i,0], xi, mu, gu, Bs[0], beta)
    lamb = penetration_depth_SC.penetration_depth(h, e, xi, jdp)
    ans_lamb.append(lamb)
    ans_xi.append(xi)
    ans_jdp.append(jdp)
    print(shape(ans_jdp))
ans_lamb = array(ans_lamb)
ans_xi   = array(ans_xi)
ans_jdp   = array(ans_jdp)

########################################################################################################################
#plot the figure of comparing free energy to extended GL
plt.scatter(kBTs, ans_jdp, 5)
plt.savefig("z.png")
plt.clf()

###################################
##output
file = open("z", "w")
file.write("##kBT-lamb" + "\n")
for i in range(n2):
    file.write(str(kBTs[i]) + " " + str(ans_xi[i]) + " "  + "\n")
file.close()
