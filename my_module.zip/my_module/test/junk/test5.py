
from numpy import *
import matplotlib.pyplot as plt
import Gap_equation_SC_BCS.Gap_equation_SC_BCS as Gap_equation_SC_BCS
import penetration_depth.penetration_depth_SC as penetration_depth_SC
import coherence_length.coherence_length as coherence_length

##パラメータの調整
N, V, t, mu, gu, n0, n1, n2, nscf =100, 2, 1 , 0.1, 0, 1, 1, 100, 10000  # 7.525 #9.21
n_search, error, check_gap =100, 1e-10, 1e-6
kBT_a, kBT_b = 0.0001, 2
wide_q = 0.001
qs   = linspace(0,wide_q,n0)         #(np.pi/a)
Bs   = linspace(0.0,0.0,n1)          #np.linspace(0,0.08,n1)
kBTs = linspace(0.001,0.202,n2)
ini_gap = 100
dq = 0.0005

ans = Gap_equation_SC_BCS.scf_2D(n0, n1, n2, kBTs, ini_gap, nscf, N, t, qs, mu, gu, Bs, V)


lamb = []
for i in range(n2):
    a = penetration_depth_SC.penetration_depth_matsunaga_2D(t, mu, gu, 0, 1/kBTs[i], V, N, ans[0,0,i,0], dq)
    lamb.append(a)
lamb = array(lamb)



########################################################################################################################
#plot the figure of comparing free energy to extended GL
plt.scatter(kBTs, lamb, 5)
plt.savefig("x2.png")
plt.clf()

###################################
##output
file = open("x2", "w")
file.write("##q-\DeltaF" + "\n")
for i in range(n2):
    file.write(str(kBTs[i]) + " " + str(lamb[i]) + " "  + "\n")
file.close()






